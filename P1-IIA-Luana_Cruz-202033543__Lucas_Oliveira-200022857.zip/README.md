# Sistema de Recomendação de Filmes

Este projeto é um sistema de recomendação de filmes que utiliza os algoritmos Naive Bayes e K-NN para fornecer recomendações de filmes com base nos dados do conjunto de dados "movies_metadata.csv" do Kaggle.

## Como Usar

Siga as etapas abaixo para configurar e executar o sistema de recomendação:

1. **Instalação das Bibliotecas Necessárias**

   Certifique-se de ter Python 3.x instalado no seu sistema. Em seguida, instale as bibliotecas necessárias executando:

```pip install -r requirements.txt```
2. 
   Execute o modelo de preferência


## Contribuição

Sinta-se à vontade para contribuir para este projeto. Se você encontrar problemas, pode relatar issues ou enviar pull requests com melhorias.
